using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneManagement : MonoBehaviour
{
    // 1. PARA EL BOT�N PLAY - va a Level1
    public void StartGame()
    {
        // Cambiar a m�sica de juego (�ndice 1)
        if (AudioManager.Instance != null)
            AudioManager.Instance.PlayMusic(1);

        SceneManager.LoadScene("Level1");
    }

    // 2. PARA EL BOT�N SETTINGS - va a ExplanationScene
    public void GoToExplanation()
    {
        SceneManager.LoadScene("ExplanationScene");
    }

    // 3. PARA EL BOT�N BACK - vuelve a MainMenu
    public void GoToMainMenu()
    {
        // Cambiar a m�sica de men� (�ndice 0)
        if (AudioManager.Instance != null)
            AudioManager.Instance.PlayMusic(0);

        SceneManager.LoadScene("MainMenu");
    }

    // 4. PARA EL BOT�N EXIT - cierra el juego
    public void ExitGame()
    {
        Debug.Log("Has cerrado el juego");
        
        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
        #else
            Application.Quit();
        #endif
    }
}
